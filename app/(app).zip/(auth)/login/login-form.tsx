"use client";

import { ArrowRight, Eye, EyeOff, Landmark } from "lucide-react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { Logo } from "@/components/brand";

const SSO_ERRORS: Record<string, string> = {
  sso_unavailable: "Government SSO is not available right now.",
  sso_denied: "Sign-in was cancelled at the SSO provider.",
  sso_failed: "Government SSO sign-in failed.",
};

export function LoginForm() {
  const params = useSearchParams();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(() => {
    const code = params.get("error");
    if (!code) return null;
    return [SSO_ERRORS[code] ?? "Sign-in failed.", params.get("detail")].filter(Boolean).join(" ");
  });
  const [sso, setSso] = useState<{ enabled: boolean; provider_name: string } | null>(null);
  const next = params.get("next");
  const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";

  useEffect(() => {
    fetch("/api/proxy/auth/sso/config")
      .then((r) => (r.ok ? r.json() : null))
      .then(setSso)
      .catch(() => setSso(null));
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim(), password }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { detail?: string };
        setError(res.status === 429 ? data.detail ?? "Too many attempts. Please wait a minute." : data.detail ?? "Sign-in failed");
        return;
      }
      window.location.assign(safeNext);
    } catch {
      setError("Cannot reach the server. Check your connection.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      {/* The showcase panel carries the brand on desktop; on mobile it is hidden, so
          the mark appears above the form instead. */}
      <Logo className="mb-10 lg:hidden" />

      <h1 className="text-[2.6rem] font-extrabold leading-none tracking-tight text-coal-900">Welcome back!</h1>
      <p className="mt-4 text-sm leading-relaxed text-muted">
        Simplify your workflow and monitor compliance with{" "}
        <span className="font-semibold text-coal-900">Lumen</span>. Sign in to continue.
      </p>

      <form onSubmit={onSubmit} className="mt-8 space-y-3" noValidate>
        <input
          id="username"
          autoComplete="username"
          required
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Username"
          aria-label="Username"
          className="h-14 w-full rounded-full border border-line-strong bg-surface px-6 text-sm text-ink outline-none transition placeholder:text-steel-400 focus:border-copper-500 focus:ring-2 focus:ring-copper-100"
        />

        <div className="relative">
          <input
            id="password"
            type={show ? "text" : "password"}
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            aria-label="Password"
            className="h-14 w-full rounded-full border border-line-strong bg-surface pl-6 pr-14 text-sm text-ink outline-none transition placeholder:text-steel-400 focus:border-copper-500 focus:ring-2 focus:ring-copper-100"
          />
          <button
            type="button"
            onClick={() => setShow((v) => !v)}
            className="absolute top-1/2 right-5 -translate-y-1/2 rounded p-1 text-steel-400 transition hover:text-coal-900"
            aria-label={show ? "Hide password" : "Show password"}
          >
            {show ? <Eye className="h-5 w-5" /> : <EyeOff className="h-5 w-5" />}
          </button>
        </div>

        <div className="flex justify-end pt-0.5">
          <Link href="/forgot-password" className="text-xs font-semibold text-coal-900 hover:text-copper-700">
            Forgot Password?
          </Link>
        </div>

        {error && (
          <p className="rounded-2xl bg-bad-soft px-4 py-3 text-sm text-bad" role="alert">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading || !username || !password}
          className="mt-2 flex h-14 w-full items-center justify-center gap-2 rounded-full bg-coal-900 text-sm font-semibold text-white transition hover:bg-coal-800 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading ? "Signing in…" : "Login"}
          {!loading && <ArrowRight className="h-4 w-4" />}
        </button>
      </form>

      <div className="my-7 flex items-center gap-4 text-xs text-muted">
        <span className="h-px flex-1 bg-line" />
        or continue with
        <span className="h-px flex-1 bg-line" />
      </div>

      <div className="flex items-center justify-center gap-5">
        {sso?.enabled ? (
          <a
            href={`/api/auth/sso/start?return_to=${encodeURIComponent(safeNext)}`}
            title={`Sign in with ${sso.provider_name}`}
            className="grid h-14 w-14 place-items-center rounded-full bg-coal-900 text-white transition hover:bg-copper-600"
          >
            <Landmark className="h-6 w-6" />
            <span className="sr-only">Sign in with {sso.provider_name}</span>
          </a>
        ) : (
          <p className="text-center text-xs text-muted">
            Single sign-on is not configured for this deployment.
          </p>
        )}
      </div>

      <p className="mt-10 text-center text-sm text-muted">
        Not a member?{" "}
        <Link href="/register" className="font-semibold text-copper-700 hover:underline">
          Register now
        </Link>
      </p>
    </div>
  );
}
