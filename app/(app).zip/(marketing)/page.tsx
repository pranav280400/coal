import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Bot,
  ClipboardCheck,
  FileText,
  MapPin,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";
import { Logo } from "@/components/brand";
import { SiteNav } from "./site-nav";

export const metadata: Metadata = {
  title: "Smarter Monitoring for Safer Mines",
  description:
    "Lumen is an AI-driven governance and compliance platform for Indian coal mines — statutory tracking, geo-tagged inspections, automated escalation and a tamper-evident audit trail.",
};

const SOLUTIONS = [
  {
    icon: ClipboardCheck,
    title: "Statutory Compliance",
    body: "Every safety, environment, production and labour obligation tracked per mine, with reminders at 7, 3 and 1 days and automatic escalation once overdue.",
  },
  {
    icon: MapPin,
    title: "Geo-tagged Inspections",
    body: "Field officers capture inspections with GPS, timestamp and photo evidence. Works fully offline and syncs the moment a signal returns.",
  },
  {
    icon: TriangleAlert,
    title: "Violation to Closure",
    body: "Flag, assign, evidence and independently verify. SLA timers drive L1 to L3 escalation so a deadline is never quietly missed.",
  },
  {
    icon: Bot,
    title: "AI Compliance Assistant",
    body: "Ask a question in plain language and get an answer grounded in the actual statute, with citations back to the regulation it came from.",
  },
  {
    icon: FileText,
    title: "Reports & Digitisation",
    body: "Scheduled statutory reports as PDF and Excel, and OCR that turns legacy paper records into structured, searchable data.",
  },
  {
    icon: ShieldCheck,
    title: "Tamper-evident Audit",
    body: "Every state change is hash-chained and write-once. Any alteration of history breaks the chain and is detected on verification.",
  },
];

const STATS = [
  { value: "142", label: "Mines monitored" },
  { value: "93%", label: "Compliance on track" },
  { value: "216", label: "Contractors verified" },
  { value: "24/7", label: "Automated oversight" },
];

export default function LandingPage() {
  return (
    <>
      <SiteNav />

      {/* ------------------------------------------------------------- hero */}
      {/*
        Desktop reproduces the brand comp exactly. `hero-scene.png` is that comp with the
        baked-in type erased, so every text layer below is live markup positioned as a
        percentage of the artwork and sized in `cqw` — the whole composition then scales
        with the container and stays locked to the illustration at any width.
        Reference geometry (1792 x 727 scene): wordmark x178 w1471 y71 · headline x71 y388
        · CTA x71 y518 h63.
      */}
      <section id="home" className="relative">
        <div className="relative hidden overflow-hidden [container-type:inline-size] lg:block">
          {/* spacer: holds the hero's height, the scene itself is layered on top */}
          <div className="w-full" style={{ aspectRatio: "1792 / 727" }} />

          {/*
            Sized from the comp: cap height 283px and width 1471px on a 1792px canvas.
            Gabarito is narrower per cap height than the face used in the comp (4.47 vs
            5.20), so a 1.163 horizontal scale makes the wordmark span the same width at
            the same height. `top` is negative because line-height:1 puts the box top
            above the cap by (ascender - capHeight).
          */}
          <h1
            className="absolute left-[9.933%] origin-left text-coal-900"
            style={{
              top: "-2.044cqw",
              fontSize: "23.19cqw",
              lineHeight: 1,
              letterSpacing: "-0.045em",
              fontWeight: 800,
              transform: "scaleX(1.1629)",
            }}
          >
            LUMEN
          </h1>

          <p
            className="absolute left-[3.96%] font-bold tracking-tight text-coal-900"
            style={{ top: "21.652cqw", fontSize: "2.85cqw", lineHeight: 1.12 }}
          >
            Smarter Monitoring
            <br />
            for Safer Mines.
          </p>

          <div className="absolute left-[3.96%] flex items-center" style={{ top: "28.906cqw", gap: "2cqw" }}>
            <Link
              href="/login"
              className="inline-flex items-center justify-center rounded-full bg-copper-600 font-bold uppercase text-white transition hover:bg-copper-700"
              style={{ height: "3.516cqw", width: "11.44cqw", fontSize: "0.94cqw", letterSpacing: "0.12em" }}
            >
              Get Started
            </Link>
            <a
              href="#solutions"
              className="group inline-flex items-center font-bold uppercase text-coal-900"
              style={{ gap: "0.9cqw", fontSize: "0.94cqw", letterSpacing: "0.12em" }}
            >
              Learn More
              <ArrowRight style={{ width: "1.3cqw", height: "1.3cqw" }} className="transition group-hover:translate-x-1" />
            </a>
          </div>

          {/*
            The mine sits in FRONT of the wordmark: in the comp its ridge crosses the
            letters. Painting it last reproduces that, and means the erased letterforms
            never need to line up with the artwork — there is nothing to mis-register.
          */}
          <Image
            src="/images/hero-scene.png"
            alt="Isometric open-cast coal mine monitored by Lumen"
            width={1792}
            height={727}
            priority
            className="pointer-events-none absolute inset-0 h-full w-full select-none"
          />
        </div>

        {/* Below lg there is no room to overlay, so the same content stacks. */}
        <div className="lg:hidden">
          <div className="px-5 pt-4 sm:px-8">
            <h1 className="display text-[20vw] text-coal-900">LUMEN</h1>
            <p className="mt-7 text-4xl font-bold leading-[1.08] tracking-tight text-coal-900 sm:text-5xl">
              Smarter Monitoring
              <br />
              for Safer Mines.
            </p>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-muted">
              AI-driven compliance monitoring for a transparent and sustainable coal sector — built for mine
              officials, corporate management and regulators.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-6 pb-8">
              <Link
                href="/login"
                className="inline-flex h-14 items-center rounded-full bg-copper-600 px-9 text-xs font-bold uppercase tracking-[0.13em] text-white transition hover:bg-copper-700"
              >
                Get Started
              </Link>
              <a
                href="#solutions"
                className="group inline-flex items-center gap-3 text-xs font-bold uppercase tracking-[0.13em] text-coal-900"
              >
                Learn More
                <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
              </a>
            </div>
          </div>
          <Image
            src="/images/hero-scene.png"
            alt="Isometric open-cast coal mine monitored by Lumen"
            width={1792}
            height={727}
            className="w-full"
          />
        </div>
      </section>

      {/* ------------------------------------------------------------ stats */}
      <section className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-[1560px] grid-cols-2 gap-px bg-line px-0 sm:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.label} className="bg-surface px-6 py-9 text-center sm:py-11">
              <p className="text-3xl font-extrabold tracking-tight text-coal-900 sm:text-4xl">{s.value}</p>
              <p className="mt-2 text-xs uppercase tracking-[0.13em] text-muted">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* -------------------------------------------------------- solutions */}
      <section id="solutions" className="mx-auto max-w-[1560px] px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <p className="eyebrow text-copper-700">Solutions</p>
        <h2 className="mt-3 max-w-2xl text-3xl font-extrabold tracking-tight text-coal-900 sm:text-4xl">
          One platform for the whole compliance lifecycle.
        </h2>
        <div className="mt-12 grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-3">
          {SOLUTIONS.map(({ icon: Icon, title, body }) => (
            <article key={title} className="group bg-canvas p-8 transition hover:bg-surface lg:p-10">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-coal-900 text-copper-400 transition group-hover:bg-copper-600 group-hover:text-white">
                <Icon className="h-6 w-6" aria-hidden />
              </span>
              <h3 className="mt-6 text-lg font-bold tracking-tight text-coal-900">{title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{body}</p>
            </article>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------ about */}
      <section id="about" className="bg-coal-900 text-white">
        <div className="mx-auto grid max-w-[1560px] gap-12 px-5 py-20 sm:px-8 lg:grid-cols-2 lg:items-center lg:px-12 lg:py-28">
          <div>
            <p className="eyebrow text-copper-400">About Lumen</p>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">
              Built for the scale of Indian coal.
            </h2>
            <p className="mt-6 max-w-xl leading-relaxed text-steel-300">
              Coal governance spans subsidiaries, mine sites, contractors and regulators — today largely joined
              by spreadsheets and paper. Lumen replaces that with a single system of record: field activity
              flows in as events, workflows chase deadlines on their own, and every change leaves a trace that
              cannot be quietly rewritten.
            </p>
            <dl className="mt-10 grid gap-8 sm:grid-cols-2">
              {[
                ["Multi-tenant by design", "Row-level scoping keeps every mine, subsidiary and contractor to their own data."],
                ["Offline-first in the field", "Idempotent sync means nothing is lost and nothing is duplicated."],
                ["Explainable AI", "Risk scores expose their drivers; the model only activates if it beats the baseline."],
                ["Runs on your infrastructure", "Self-hosted and air-gap capable, with no data leaving the network."],
              ].map(([t, b]) => (
                <div key={t}>
                  <dt className="font-semibold text-white">{t}</dt>
                  <dd className="mt-1.5 text-sm leading-relaxed text-steel-300">{b}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="overflow-hidden rounded-3xl border border-white/10">
            <Image
              src="/images/iso-hero-depot.03bcafb7.webp"
              alt="Coal mining operations overseen through Lumen"
              width={1200}
              height={800}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------- contact */}
      <section id="contact" className="mx-auto max-w-[1560px] px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
        <div className="rounded-[2rem] bg-surface p-10 shadow-card lg:p-16">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="eyebrow text-copper-700">Contact</p>
              <h2 className="mt-3 max-w-xl text-3xl font-extrabold tracking-tight text-coal-900 sm:text-4xl">
                See Lumen against your own mine data.
              </h2>
              <p className="mt-4 max-w-lg text-muted">
                We will walk through compliance tracking, a live inspection, an escalation as it fires, and the
                audit trail behind it.
              </p>
            </div>
            <div className="flex shrink-0 flex-col gap-3 sm:flex-row lg:flex-col">
              <Link
                href="/login"
                className="inline-flex h-14 items-center justify-center rounded-full bg-copper-600 px-9 text-xs font-bold uppercase tracking-[0.13em] text-white transition hover:bg-copper-700"
              >
                Request Demo
              </Link>
              <Link
                href="/login"
                className="inline-flex h-14 items-center justify-center rounded-full border border-line-strong px-9 text-xs font-bold uppercase tracking-[0.13em] text-coal-900 transition hover:bg-canvas"
              >
                Sign In
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------------- footer */}
      <footer className="border-t border-line bg-canvas">
        <div className="mx-auto flex max-w-[1560px] flex-col gap-6 px-5 py-10 sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:px-12">
          <Logo />
          <p className="text-sm text-muted">
            Ministry of Coal · Government of India — Problem Statement 26024, Smart India Hackathon 2026
          </p>
        </div>
      </footer>
    </>
  );
}
