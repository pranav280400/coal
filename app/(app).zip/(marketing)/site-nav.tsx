"use client";

import Link from "next/link";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Logo } from "@/components/brand";
import { cn } from "@/components/ui";

const LINKS = [
  { href: "#home", label: "Home" },
  { href: "#solutions", label: "Solutions" },
  { href: "#about", label: "About" },
  { href: "#contact", label: "Contact" },
];

/** Language switch is presentational for now — the API already returns Hindi copy. */
function LangToggle({ className }: { className?: string }) {
  const [lang, setLang] = useState<"EN" | "IN">("EN");
  return (
    <div className={cn("flex items-center rounded-full bg-coal-900 p-1", className)} role="group" aria-label="Language">
      {(["EN", "IN"] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            "h-9 w-12 rounded-full text-sm font-semibold tracking-wide transition",
            lang === l ? "bg-white text-coal-900" : "text-white/80 hover:text-white",
          )}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

export function SiteNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="relative z-30">
      <div className="mx-auto flex max-w-[1792px] items-center justify-between gap-6 px-5 py-5 sm:px-8 lg:px-12 lg:py-8">
        <Link href="/" aria-label="Lumen home">
          <Logo size="lg" className="lg:[&>svg]:h-14 lg:[&>svg]:w-14 lg:[&>span]:text-3xl" />
        </Link>

        <nav className="hidden items-center gap-10 lg:flex" aria-label="Primary">
          {LINKS.map((l, i) => (
            <a
              key={l.href}
              href={l.href}
              className={cn(
                "relative py-1 text-sm font-semibold uppercase tracking-[0.13em] text-coal-900 transition hover:text-copper-700",
                i === 0 && "after:absolute after:-bottom-1.5 after:left-0 after:h-[3px] after:w-8 after:bg-copper-600",
              )}
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            href="/login"
            className="hidden h-14 items-center rounded-full bg-copper-600 px-9 text-sm font-bold uppercase tracking-[0.13em] text-white transition hover:bg-copper-700 sm:inline-flex"
          >
            Request Demo
          </Link>
          <LangToggle className="hidden sm:flex" />
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className="grid h-11 w-11 place-items-center rounded-full bg-coal-900 text-white lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-canvas px-5 pb-6 pt-2 sm:px-8 lg:hidden">
          <nav className="flex flex-col" aria-label="Primary mobile">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="border-b border-line py-4 text-lg font-semibold text-coal-900"
              >
                {l.label}
              </a>
            ))}
          </nav>
          <div className="mt-5 flex items-center gap-3">
            <Link
              href="/login"
              className="inline-flex h-12 flex-1 items-center justify-center rounded-full bg-copper-600 px-6 text-xs font-bold uppercase tracking-[0.13em] text-white"
            >
              Request Demo
            </Link>
            <LangToggle />
          </div>
        </div>
      )}
    </header>
  );
}
