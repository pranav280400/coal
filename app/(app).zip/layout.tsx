import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { Providers } from "@/components/providers";
import "./globals.css";

// Self-hosted so `next build` never needs to reach fonts.googleapis.com — the image
// builds identically offline / in an air-gapped government network. See app/fonts/README.md.
const gabarito = localFont({
  variable: "--font-gabarito",
  display: "swap",
  src: "./fonts/gabarito-latin.woff2",
  weight: "400 900",
  style: "normal",
  fallback: ["ui-sans-serif", "system-ui", "sans-serif"],
});

export const metadata: Metadata = {
  title: { default: "Lumen", template: "%s · Lumen" },
  description: "AI-based Smart Governance & Compliance Monitoring System for Coal Mines — Ministry of Coal",
  applicationName: "Lumen",
  appleWebApp: { capable: true, title: "Lumen", statusBarStyle: "black-translucent" },
  icons: { icon: "/icons/icon.svg", apple: "/icons/icon-192.png" },
};

export const viewport: Viewport = {
  themeColor: "#121416",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${gabarito.variable} h-full antialiased`}>
      <body className="min-h-full">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
