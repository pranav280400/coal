"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bot, MessageSquarePlus, Search, Send, Trash, User } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { toast } from "sonner";
import { Badge, Button, Card, cn, EmptyState, Input, Loading, PageHeader, Select, Tabs } from "@/components/ui";
import { api, errorMessage, sse } from "@/lib/api";
import { fromNow, humanize } from "@/lib/format";
import type { ChatMessage, ChatSession, Citation, SimilarItem } from "@/lib/types";

type Tab = "chat" | "search";

const LANGS = [
  { value: "auto", label: "Auto-detect" },
  { value: "en", label: "English" },
  { value: "hi", label: "हिन्दी" },
  { value: "bn", label: "বাংলা" },
  { value: "or", label: "ଓଡ଼ିଆ" },
  { value: "te", label: "తెలుగు" },
  { value: "mr", label: "मराठी" },
  { value: "ta", label: "தமிழ்" },
];

const SUGGESTIONS = [
  "What are the ventilation standards for underground coal mines?",
  "Which of my mines have the most overdue statutory items?",
  "खुली खदानों में हॉल रोड के लिए सुरक्षा नियम क्या हैं?",
  "Summarise contractor obligations under the Contract Labour Act.",
];

function sourceHref(c: Citation): string | null {
  if (c.source_type === "violation") return `/violations/${c.source_id}`;
  if (c.source_type === "inspection") return `/inspections/${c.source_id}`;
  if (c.source_type === "document") return `/documents/${c.source_id}`;
  return null;
}

function Citations({ items }: { items: Citation[] }) {
  if (!items.length) return null;
  return (
    <div className="mt-3 flex flex-wrap gap-1.5">
      {items.map((c) => {
        const href = sourceHref(c);
        const chip = (
          <span className="inline-flex max-w-72 items-center gap-1 truncate rounded-lg bg-copper-50 px-2 py-1 text-xs text-copper-600" title={c.snippet}>
            <strong>[{c.index}]</strong> {c.title}
          </span>
        );
        return href ? <Link key={c.index} href={href}>{chip}</Link> : <span key={c.index}>{chip}</span>;
      })}
    </div>
  );
}

function Chat() {
  const params = useSearchParams();
  const router = useRouter();
  const qc = useQueryClient();
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string; citations?: Citation[] }[]>([]);
  const [input, setInput] = useState("");
  const [lang, setLang] = useState("auto");
  const [busy, setBusy] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const initial = useRef(params.get("q"));

  const { data: sessions = [] } = useQuery({ queryKey: ["chat-sessions"], queryFn: () => api<ChatSession[]>("/ai/sessions") });
  const del = useMutation({
    mutationFn: (id: string) => api(`/ai/sessions/${id}`, { method: "DELETE" }),
    onSuccess: (_, id) => {
      void qc.invalidateQueries({ queryKey: ["chat-sessions"] });
      if (id === sessionId) { setSessionId(null); setMessages([]); }
    },
  });

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages]);

  const load = async (id: string) => {
    abortRef.current?.abort();
    setSessionId(id);
    const history = await api<ChatMessage[]>(`/ai/sessions/${id}/messages`);
    setMessages(history.map((m) => ({ role: m.role, content: m.content, citations: m.citations ?? [] })));
  };

  const send = useCallback(
    async (text: string) => {
      const q = text.trim();
      if (!q || busy) return;
      setInput("");
      setBusy(true);
      setMessages((m) => [...m, { role: "user", content: q }, { role: "assistant", content: "", citations: [] }]);
      const ctrl = new AbortController();
      abortRef.current = ctrl;
      try {
        for await (const ev of sse("/ai/chat", { message: q, session_id: sessionId, language: lang }, ctrl.signal)) {
          const data = ev.data as Record<string, unknown>;
          if (ev.event === "meta") {
            setSessionId(data.session_id as string);
            const cites = data.citations as Citation[];
            setMessages((m) => m.map((x, i) => (i === m.length - 1 ? { ...x, citations: cites } : x)));
          } else if (ev.event === "token") {
            setMessages((m) => m.map((x, i) => (i === m.length - 1 ? { ...x, content: x.content + (data.t as string) } : x)));
          } else if (ev.event === "error") {
            setMessages((m) => m.map((x, i) => (i === m.length - 1 ? { ...x, content: `⚠️ ${data.detail as string}` } : x)));
          }
        }
        void qc.invalidateQueries({ queryKey: ["chat-sessions"] });
      } catch (e) {
        if (!ctrl.signal.aborted) {
          setMessages((m) => m.map((x, i) => (i === m.length - 1 ? { ...x, content: `⚠️ ${errorMessage(e)}` } : x)));
        }
      } finally {
        setBusy(false);
      }
    },
    [busy, lang, qc, sessionId],
  );

  useEffect(() => {
    if (initial.current) {
      const q = initial.current;
      initial.current = null;
      router.replace("/assistant");
      void send(q);
    }
  }, [router, send]);

  return (
    <div className="grid gap-5 lg:grid-cols-[260px_1fr]">
      <Card className="hidden max-h-[72vh] flex-col lg:flex">
        <div className="border-b border-line p-3">
          <Button variant="secondary" className="w-full" onClick={() => { abortRef.current?.abort(); setSessionId(null); setMessages([]); }}>
            <MessageSquarePlus className="h-4 w-4" /> New conversation
          </Button>
        </div>
        <ul className="scroll-thin flex-1 space-y-0.5 overflow-y-auto p-2">
          {sessions.map((s) => (
            <li key={s.id} className={cn("group flex items-center rounded-lg", s.id === sessionId ? "bg-copper-50" : "hover:bg-canvas")}>
              <button onClick={() => void load(s.id)} className="min-w-0 flex-1 px-2.5 py-2 text-left">
                <span className="block truncate text-sm">{s.title}</span>
                <span className="text-xs text-muted">{fromNow(s.updated_at)}</span>
              </button>
              <button onClick={() => del.mutate(s.id)} className="mr-1 hidden rounded p-1 text-muted hover:text-bad group-hover:block" aria-label="Delete conversation">
                <Trash className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
          {!sessions.length && <li className="p-3 text-sm text-muted">No conversations yet.</li>}
        </ul>
      </Card>

      <Card className="flex h-[72vh] flex-col">
        <div className="scroll-thin flex-1 space-y-4 overflow-y-auto p-5">
          {!messages.length && (
            <div className="mx-auto max-w-xl py-10 text-center">
              <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-copper-50 text-copper-700"><Bot className="h-7 w-7" /></span>
              <h2 className="mt-4 text-lg font-semibold">Compliance assistant</h2>
              <p className="mt-1 text-sm text-muted">
                Answers are grounded in the statutory library, your inspection reports, violations and digitised documents — with citations. Ask in English, Hindi or other Indian languages.
              </p>
              <div className="mt-6 grid gap-2 sm:grid-cols-2">
                {SUGGESTIONS.map((s) => (
                  <button key={s} onClick={() => void send(s)} className="rounded-xl border border-line p-3 text-left text-sm hover:border-copper-400 hover:bg-copper-50">{s}</button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={cn("flex gap-3", m.role === "user" && "flex-row-reverse")}>
              <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-full", m.role === "user" ? "bg-copper-600 text-white" : "bg-copper-50 text-copper-700")}>
                {m.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </span>
              <div className={cn("max-w-[85%] rounded-2xl px-4 py-3 text-sm", m.role === "user" ? "bg-copper-600 text-white" : "bg-canvas")}>
                {m.role === "assistant" ? (
                  m.content ? (
                    <div className="markdown"><ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown></div>
                  ) : (
                    <span className="flex gap-1 py-1" aria-label="Thinking"><span className="h-2 w-2 animate-bounce rounded-full bg-muted" /><span className="h-2 w-2 animate-bounce rounded-full bg-muted [animation-delay:120ms]" /><span className="h-2 w-2 animate-bounce rounded-full bg-muted [animation-delay:240ms]" /></span>
                  )
                ) : (
                  <p className="whitespace-pre-line">{m.content}</p>
                )}
                {m.citations && <Citations items={m.citations} />}
              </div>
            </div>
          ))}
          <div ref={endRef} />
        </div>
        <form onSubmit={(e) => { e.preventDefault(); void send(input); }} className="flex gap-2 border-t border-line p-3">
          <Select value={lang} onChange={(e) => setLang(e.target.value)} className="w-36" aria-label="Answer language">
            {LANGS.map((l) => <option key={l.value} value={l.value}>{l.label}</option>)}
          </Select>
          <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about regulations, inspections, risks…" disabled={busy} aria-label="Message" />
          <Button type="submit" disabled={busy || !input.trim()} aria-label="Send"><Send className="h-4 w-4" /></Button>
        </form>
      </Card>
    </div>
  );
}

function SemanticSearch() {
  const [q, setQ] = useState("");
  const [types, setTypes] = useState<string[]>([]);
  const search = useMutation({
    mutationFn: () => api<SimilarItem[]>("/ai/search", { body: { query: q, source_types: types.length ? types : null, limit: 20 } }),
    onError: (e) => toast.error(errorMessage(e)),
  });
  const toggle = (t: string) => setTypes((s) => (s.includes(t) ? s.filter((x) => x !== t) : [...s, t]));
  return (
    <Card className="p-5">
      <form onSubmit={(e) => { e.preventDefault(); if (q.trim().length >= 2) search.mutate(); }} className="flex gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Describe what you're looking for, e.g. 'dust suppression failures near haul roads'" />
        <Button type="submit" loading={search.isPending}><Search className="h-4 w-4" /> Search</Button>
      </form>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {["regulation", "inspection", "violation", "document"].map((t) => (
          <button key={t} onClick={() => toggle(t)} className={cn("rounded-lg px-2.5 py-1 text-xs font-medium", types.includes(t) ? "bg-copper-600 text-white" : "bg-canvas")}>{humanize(t)}s</button>
        ))}
      </div>
      <div className="mt-5">
        {search.isPending ? <Loading label="Searching vectors…" /> : search.data ? (
          search.data.length ? (
            <ul className="space-y-2">
              {search.data.map((h) => {
                const href = sourceHref({ index: 0, source_type: h.source_type, source_id: h.source_id, title: h.title, score: h.score, snippet: h.snippet });
                const inner = (
                  <div className="rounded-xl border border-line p-3 hover:bg-canvas">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium">{h.title}</span>
                      <span className="flex gap-1.5"><Badge tone="neutral">{h.source_type}</Badge><Badge tone="info">{Math.round(h.score * 100)}%</Badge></span>
                    </div>
                    <p className="mt-1 line-clamp-3 text-sm text-muted">{h.snippet}</p>
                  </div>
                );
                return <li key={`${h.source_type}-${h.source_id}-${h.snippet.slice(0, 10)}`}>{href ? <Link href={href}>{inner}</Link> : inner}</li>;
              })}
            </ul>
          ) : <EmptyState title="No matches" body="Try different wording — search works on meaning, not keywords." />
        ) : <p className="text-sm text-muted">Semantic search across regulations, inspection reports, violations and OCR-digitised documents.</p>}
      </div>
    </Card>
  );
}

function AssistantInner() {
  const [tab, setTab] = useState<Tab>("chat");
  return (
    <div>
      <PageHeader title="AI Assistant" subtitle="Multilingual, retrieval-augmented compliance assistant (LiteLLM → vLLM, grounded via Qdrant)" />
      <div className="mb-4">
        <Tabs<Tab> value={tab} onChange={setTab} tabs={[{ value: "chat", label: "Assistant" }, { value: "search", label: "Semantic search" }]} />
      </div>
      {tab === "chat" ? <Chat /> : <SemanticSearch />}
    </div>
  );
}

export default function AssistantPage() {
  return (
    <Suspense fallback={<Loading />}>
      <AssistantInner />
    </Suspense>
  );
}
