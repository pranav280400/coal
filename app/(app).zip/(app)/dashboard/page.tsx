"use client";

import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  Bot,
  CalendarClock,
  ClipboardList,
  CloudSun,
  FileSearch,
  HardHat,
  Scale,
  Search,
  Send,
  TriangleAlert,
  UserPlus,
  Users,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import { CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { MineMap } from "@/components/map";
import { useSession } from "@/components/session";
import { Badge, Card, CardHeader, cn, ErrorState, Loading } from "@/components/ui";
import { api, errorMessage } from "@/lib/api";
import { fmtDate, fmtNumber, humanize, outcomeLabel, outcomeTone } from "@/lib/format";
import type { DashboardSummary } from "@/lib/types";

/** Current month as a readable range, matching the dashboard's reporting period. */
function periodLabel(): string {
  const now = new Date();
  const first = new Date(now.getFullYear(), now.getMonth(), 1);
  const last = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const f = (d: Date) => d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  return `${f(first)} – ${f(last)}`;
}

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? "Good Morning" : h < 17 ? "Good Afternoon" : "Good Evening";
}

function Kpi({
  icon,
  tone,
  label,
  value,
  foot,
  footTone = "text-ok",
  href,
}: {
  icon: ReactNode;
  tone: string;
  label: string;
  value: string;
  foot: string;
  footTone?: string;
  href: string;
}) {
  return (
    <Link href={href} className="group rounded-2xl border border-line bg-surface p-4 shadow-card transition hover:-translate-y-0.5 hover:shadow-lift">
      <div className="flex items-center gap-3">
        <span className={cn("grid h-12 w-12 shrink-0 place-items-center rounded-full", tone)}>{icon}</span>
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-muted">{label}</p>
          <p className="text-2xl font-bold tabular-nums">{value}</p>
          <p className={cn("truncate text-xs font-semibold", footTone)}>{foot}</p>
        </div>
      </div>
    </Link>
  );
}

function ComplianceDonut({ data }: { data: DashboardSummary["compliance"] }) {
  const slices = [
    { name: "Compliant", value: data.overview.compliant, color: "#11513c" },
    { name: "In Progress", value: data.overview.in_progress, color: "#e0a100" },
    { name: "Non-Compliant", value: data.overview.non_compliant, color: "#dc3a3a" },
  ];
  return (
    <div className="flex flex-col items-center gap-4 px-5 pb-5 sm:flex-row">
      <div className="relative h-44 w-44 shrink-0">
        <ResponsiveContainer>
          <PieChart>
            <Pie data={slices} dataKey="value" innerRadius={58} outerRadius={80} startAngle={90} endAngle={-270} stroke="none">
              {slices.map((s) => (
                <Cell key={s.name} fill={s.color} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
          <div>
            <p className="text-3xl font-bold">{Math.round(data.compliance_rate)}%</p>
            <p className="text-xs text-muted">Overall</p>
          </div>
        </div>
      </div>
      <ul className="w-full space-y-3 text-sm">
        {slices.map((s) => (
          <li key={s.name} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
            <span className="flex-1">{s.name}</span>
            <span className="font-semibold tabular-nums">{s.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function AssistantWidget() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const go = (text: string) => router.push(`/assistant?q=${encodeURIComponent(text)}`);
  const prompts = [
    { icon: FileSearch, text: "Summarize latest inspection report" },
    { icon: Search, text: "Find similar violations" },
    { icon: Scale, text: "Ask about compliance rules" },
  ];
  return (
    <Card>
      <CardHeader title={<span className="flex items-center gap-2"><Bot className="h-5 w-5 text-copper-600" /> AI Assistant</span>} />
      <div className="space-y-2 px-5 pb-5">
        {prompts.map(({ icon: Icon, text }) => (
          <button
            key={text}
            onClick={() => go(text === "Summarize latest inspection report" ? "Summarise the most recent inspection findings for my mines and highlight hazards." : text === "Find similar violations" ? "Find past violations similar to the most recent high-severity violation and what corrective actions worked." : "What are the statutory requirements for haul road berms and traffic rules in opencast mines?")}
            className="flex w-full items-center gap-2.5 rounded-xl border border-line px-3 py-2.5 text-left text-sm hover:border-copper-400 hover:bg-copper-50"
          >
            <Icon className="h-4 w-4 text-copper-700" /> {text}
          </button>
        ))}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (q.trim()) go(q.trim());
          }}
          className="flex gap-2 pt-1"
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Type your question…"
            aria-label="Ask the AI assistant"
            className="h-11 flex-1 rounded-xl border border-line bg-canvas px-3 text-sm outline-none focus:border-copper-400 focus:bg-white"
          />
          <button type="submit" className="grid h-11 w-11 place-items-center rounded-xl bg-copper-600 text-white hover:bg-copper-700" aria-label="Send">
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </Card>
  );
}

function MobileGreeting({ name, mineName, coords }: { name: string; mineName: string | null; coords: { lat: number; lon: number } | null }) {
  const { data: weather } = useQuery({
    queryKey: ["weather", coords?.lat, coords?.lon],
    queryFn: () => fetch(`/api/weather?lat=${coords!.lat}&lon=${coords!.lon}`).then((r) => (r.ok ? r.json() : null)),
    enabled: !!coords,
    staleTime: 15 * 60_000,
  });
  return (
    <div className="relative -mx-4 -mt-5 mb-4 overflow-hidden px-4 pt-5 pb-14 text-white lg:hidden">
      <Image src="/images/coal-texture.jpg" alt="" fill className="object-cover" sizes="100vw" priority />
      <div className="absolute inset-0 bg-gradient-to-b from-coal-900 via-coal-900/70 to-coal-900/40" />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <p className="text-2xl leading-tight font-bold">
            {greeting()},
            <br />
            {name.split(" ")[0]}!
          </p>
          {mineName && <p className="mt-1 text-sm text-white/85">{mineName}</p>}
        </div>
        {weather && (
          <div className="flex items-center gap-2 rounded-2xl border border-white/30 bg-white/10 px-3 py-2 backdrop-blur">
            <CloudSun className="h-6 w-6 text-amber-300" />
            <div className="leading-tight">
              <p className="font-bold">{weather.temperature_c}°C</p>
              <p className="text-xs text-white/80">{weather.condition}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { me, can } = useSession();
  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => api<DashboardSummary>("/dashboard/summary"),
    refetchInterval: 60_000,
  });
  if (isLoading) return <Loading label="Loading dashboard…" />;
  if (error || !data) return <ErrorState message={errorMessage(error)} onRetry={() => refetch()} />;
  const k = data.kpis;
  const myMine = me.mine_id ? data.mine_locations.find((m) => m.id === me.mine_id) : undefined;
  const coords = myMine ? { lat: myMine.latitude, lon: myMine.longitude } : data.mine_locations[0] ? { lat: data.mine_locations[0].latitude, lon: data.mine_locations[0].longitude } : null;

  return (
    <div className="space-y-5">
      <MobileGreeting name={me.full_name} mineName={me.mine?.name ?? me.subsidiary_name} coords={coords} />

      {/* page header — plain type on the warm canvas, actions pinned right */}
      <section className="hidden items-start justify-between gap-6 pt-1 lg:flex">
        <div className="min-w-0">
          <p className="text-sm text-muted">Welcome back, {me.full_name}</p>
          <h1 className="mt-1 text-4xl font-extrabold tracking-tight text-coal-900">Safer Mines. Stronger India.</h1>
          <p className="mt-2 text-muted">
            AI-driven compliance monitoring for a transparent and sustainable coal sector.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-3">
          <span className="inline-flex h-12 items-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm text-ink">
            <CalendarClock className="h-4 w-4 text-muted" aria-hidden />
            {periodLabel()}
          </span>
          <Link
            href="/reports"
            className="inline-flex h-12 items-center gap-2 rounded-xl bg-copper-600 px-5 text-sm font-semibold text-white transition hover:bg-copper-700"
          >
            <FileSearch className="h-4 w-4" aria-hidden />
            Generate Report
          </Link>
        </div>
      </section>

      {/* KPI row */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <Kpi href="/map" icon={<ClipboardList className="h-6 w-6" />} tone="bg-ok-soft text-ok" label="Total Mines"
          value={fmtNumber(k.total_mines)} foot={k.new_mines_this_month ? `+${k.new_mines_this_month} this month` : "All onboarded"} />
        <Kpi href="/compliance" icon={<CalendarClock className="h-6 w-6" />} tone="bg-info-soft text-info" label="Compliance Items"
          value={fmtNumber(k.compliance_items)} foot={`${Math.round(k.compliance_rate)}% on track`} />
        <Kpi href="/violations?open_only=true" icon={<TriangleAlert className="h-6 w-6" />} tone="bg-bad-soft text-bad" label="Open Violations"
          value={fmtNumber(k.open_violations)} foot={`${k.critical_violations} critical`} footTone={k.critical_violations ? "text-bad" : "text-ok"} />
        <Kpi href="/contractors" icon={<Users className="h-6 w-6" />} tone="bg-violet-soft text-violet" label="Active Contractors"
          value={fmtNumber(k.active_contractors)} foot={k.verified_contractors === k.active_contractors ? "All verified" : `${k.verified_contractors} verified`} />
        <Kpi href="/inspections" icon={<Search className="h-6 w-6" />} tone="bg-copper-50 text-copper-600" label="Inspections"
          value={fmtNumber(k.inspections)}
          foot={k.inspections_change_pct === null ? `${k.inspections_this_month} this month` : `${k.inspections_change_pct >= 0 ? "+" : ""}${k.inspections_change_pct}% this month`}
          footTone={k.inspections_change_pct !== null && k.inspections_change_pct < 0 ? "text-warn" : "text-ok"} />
      </div>

      {/* mobile quick actions */}
      <Card className="lg:hidden">
        <CardHeader title="Quick Actions" />
        <div className="grid grid-cols-4 gap-2 px-4 pb-4 text-center text-[11px] font-medium">
          {[
            { href: "/inspections/new", label: "New Inspection", icon: ClipboardList, tone: "bg-ok-soft text-ok", perm: "inspection:write" },
            { href: "/violations/new", label: "Add Violation", icon: TriangleAlert, tone: "bg-bad-soft text-bad", perm: "violation:write" },
            { href: "/contractors?new=1", label: "Register Contractor", icon: UserPlus, tone: "bg-violet-soft text-violet", perm: "contractor:write" },
            { href: "/assistant", label: "AI Assistant", icon: Bot, tone: "bg-info-soft text-info", perm: "ai:use" },
          ]
            .filter((a) => can(a.perm))
            .map(({ href, label, icon: Icon, tone }) => (
              <Link key={href} href={href} className="flex flex-col items-center gap-2 rounded-2xl border border-line p-2.5">
                <span className={cn("grid h-11 w-11 place-items-center rounded-full", tone)}>
                  <Icon className="h-5 w-5" />
                </span>
                {label}
              </Link>
            ))}
        </div>
      </Card>

      <div className="grid gap-5 xl:grid-cols-3">
        <Card>
          <CardHeader title="Compliance Overview" action={<Link href="/compliance" className="text-xs font-semibold text-copper-700">View Details →</Link>} />
          <ComplianceDonut data={data.compliance} />
        </Card>

        <Card>
          <CardHeader title="Recent Inspections" action={<Link href="/inspections" className="text-xs font-semibold text-copper-700">View All →</Link>} />
          <ul className="divide-y divide-line px-5 pb-3">
            {data.recent_inspections.length === 0 && <li className="py-6 text-center text-sm text-muted">No inspections yet.</li>}
            {data.recent_inspections.slice(0, 4).map((i) => (
              <li key={i.id}>
                <Link href={`/inspections/${i.id}`} className="flex items-center gap-3 py-2.5">
                  <span className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-lg", i.outcome === "compliant" ? "bg-ok-soft text-ok" : i.outcome === "minor_issues" ? "bg-warn-soft text-warn" : "bg-bad-soft text-bad")}>
                    <ClipboardList className="h-4 w-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold">{i.mine_name}</span>
                    <span className="block truncate text-xs text-muted">{humanize(i.inspection_type)} Inspection</span>
                  </span>
                  <span className="hidden text-xs text-muted sm:block">{fmtDate(i.inspected_at, "MMM d, yyyy")}</span>
                  <Badge tone={outcomeTone[i.outcome]}>{outcomeLabel[i.outcome]}</Badge>
                </Link>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader title="Mine Locations" action={<Link href="/map" className="text-xs font-semibold text-copper-700">View Map →</Link>} />
          <div className="mx-5 h-52 overflow-hidden rounded-xl">
            <MineMap mines={data.mine_locations} focusId={me.mine_id} interactive={false} />
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 px-5 py-3 text-xs">
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-ok" /> Compliant</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-warn" /> Minor Issues</span>
            <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-bad" /> Non-Compliant</span>
          </div>
        </Card>

        <Card>
          <CardHeader title="Upcoming Deadlines" action={<Link href="/compliance" className="text-xs font-semibold text-copper-700">View All →</Link>} />
          <ul className="space-y-1 px-5 pb-4">
            {data.upcoming_deadlines.length === 0 && <li className="py-6 text-center text-sm text-muted">Nothing due.</li>}
            {data.upcoming_deadlines.slice(0, 4).map((d) => (
              <li key={d.id}>
                <Link href={`/compliance?item=${d.id}`} className="flex items-center gap-3 rounded-xl py-2 hover:bg-canvas">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-bad-soft text-bad">
                    <CalendarClock className="h-4 w-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold">{d.title}</span>
                    <span className="block truncate text-xs text-muted">{d.mine_name}</span>
                  </span>
                  <Badge tone={d.days_left < 0 ? "bad" : d.days_left <= 7 ? "bad" : d.days_left <= 14 ? "warn" : "neutral"}>
                    {d.days_left < 0 ? `Overdue ${-d.days_left}d` : d.days_left === 0 ? "Due today" : `Due in ${d.days_left} days`}
                  </Badge>
                </Link>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader title="Violation Trends" subtitle="Last 6 months" action={<Link href="/reports" className="text-xs font-semibold text-copper-700">Analytics →</Link>} />
          <div className="h-60 px-2 pb-4">
            <ResponsiveContainer>
              <LineChart data={data.violation_trends} margin={{ top: 5, right: 16, left: -12, bottom: 0 }}>
                <CartesianGrid stroke="#e2e9e5" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: "#5c6f66" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: "#5c6f66" }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #e2e9e5" }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="total" name="Total" stroke="#11513c" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="critical" name="Critical" stroke="#dc3a3a" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="resolved" name="Resolved" stroke="#3b6fd8" strokeWidth={2} strokeDasharray="4 3" dot={{ r: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {can("ai:use") ? (
          <AssistantWidget />
        ) : (
          <Card>
            <CardHeader title="High-risk mines" />
            <HighRiskList items={data.high_risk_mines} />
          </Card>
        )}
      </div>

      {can("ai:use") && data.high_risk_mines.length > 0 && (
        <Card>
          <CardHeader
            title="AI risk watchlist"
            subtitle="Mines ranked by predicted compliance risk (explainable model)"
            action={<Link href="/reports?tab=risk" className="flex items-center gap-1 text-xs font-semibold text-copper-700">Risk analytics <ArrowRight className="h-3 w-3" /></Link>}
          />
          <HighRiskList items={data.high_risk_mines} />
        </Card>
      )}
      {k.open_anomalies > 0 && (
        <Link href="/reports?tab=anomalies" className="flex items-center gap-3 rounded-2xl border border-warn/30 bg-warn-soft px-5 py-3 text-sm font-medium text-warn">
          <HardHat className="h-5 w-5" /> {k.open_anomalies} open anomaly alert{k.open_anomalies > 1 ? "s" : ""} detected by the analytics engine — review now
          <ArrowRight className="ml-auto h-4 w-4" />
        </Link>
      )}
    </div>
  );
}

function HighRiskList({ items }: { items: DashboardSummary["high_risk_mines"] }) {
  return (
    <ul className="grid gap-2 px-5 pb-5 sm:grid-cols-2 xl:grid-cols-5">
      {items.map((m) => (
        <li key={m.id} className="rounded-xl border border-line p-3">
          <p className="truncate text-sm font-semibold">{m.name}</p>
          <p className="text-xs text-muted">{m.code}</p>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-canvas">
            <div
              className={cn("h-full rounded-full", (m.risk_score ?? 0) >= 60 ? "bg-bad" : (m.risk_score ?? 0) >= 35 ? "bg-warn" : "bg-ok")}
              style={{ width: `${Math.min(100, m.risk_score ?? 0)}%` }}
            />
          </div>
          <p className="mt-1 text-right text-xs font-semibold tabular-nums">{m.risk_score?.toFixed(0) ?? "—"} / 100</p>
        </li>
      ))}
    </ul>
  );
}
