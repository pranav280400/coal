# Vendored fonts

`gabarito-latin.woff2` is the Gabarito variable font (weights 400-900, `latin` subset),
copied here so `next build` never needs network access to fonts.googleapis.com. The
image therefore builds identically offline and in air-gapped government networks.

* Family: Gabarito - https://fonts.google.com/specimen/Gabarito
* Licence: SIL Open Font License 1.1 - https://openfontlicense.org
  (the OFL permits bundling and self-hosting; keep this notice with the file)

Loaded via `next/font/local` in `app/layout.tsx`. To refresh it, read the `latin`
`@font-face` block from
`https://fonts.googleapis.com/css2?family=Gabarito:wght@400..900&display=swap`
and download the woff2 URL it points at.
